# Spotify Crack - Chrome App
<h2>For MacOS, Windows & Linux

## What's New:

- Removed all ads
- No need to skip ads
- Removed premium and install buttons😁

<img width="1440" alt="Screenshot 2022-01-08 at 9 34 45 AM" src="https://user-images.githubusercontent.com/83419951/148630845-7035d19b-895b-4b5b-aca4-ac5f61432391.png">
  
## How to install

1. Clone or download this repo into a folder.
1. Go to chrome://extensions
2. Make sure **Developer mode** (in the upper right corner) is ON.
3. Drag & drop the folder that contains this repo there.
4. Open Spotify Web and open chrome `Options > More Tools > Create Shortcut...`
5. Check `Open as window` & hit Create
6. Open Spotify as App
7. Don't delete folder containing repo else it won't work.
